<?php
/**
 * Theme Functions
 *
 * @author Jegtheme
 * @package lets-explore-ni
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

defined( 'LETS_EXPLORE_NI_VERSION' ) || define( 'LETS_EXPLORE_NI_VERSION', '1.7.0' );
defined( 'LETS_EXPLORE_NI_DIR' ) || define( 'LETS_EXPLORE_NI_DIR', trailingslashit( get_template_directory() ) );

defined( 'GUTENVERSE_COMPANION_REQUIRED_VERSION' ) || define( 'GUTENVERSE_COMPANION_REQUIRED_VERSION', '1.0.5' );
defined( 'GUTENVERSE_FRAMEWORK_REQUIRED_VERSION' ) || define( 'GUTENVERSE_FRAMEWORK_REQUIRED_VERSION', '2.0.0' );

require get_parent_theme_file_path( 'inc/autoload.php' );

LetsExploreNI\Init::instance();

/**
 * Register the campervan fleet content type.
 */
function leni_register_campervan_post_type() {
    $labels = array(
        'name'               => __( 'Campervans', 'lets-explore-ni' ),
        'singular_name'      => __( 'Campervan', 'lets-explore-ni' ),
        'add_new_item'       => __( 'Add New Campervan', 'lets-explore-ni' ),
        'edit_item'          => __( 'Edit Campervan', 'lets-explore-ni' ),
        'new_item'           => __( 'New Campervan', 'lets-explore-ni' ),
        'view_item'          => __( 'View Campervan', 'lets-explore-ni' ),
        'search_items'       => __( 'Search Campervans', 'lets-explore-ni' ),
        'not_found'          => __( 'No campervans found.', 'lets-explore-ni' ),
        'menu_name'          => __( 'Campervans', 'lets-explore-ni' ),
    );

    register_post_type(
        'campervan',
        array(
            'labels'             => $labels,
            'public'             => true,
            'show_in_rest'       => true,
            'menu_icon'          => 'dashicons-car',
            'has_archive'        => 'campervans',
            'rewrite'            => array( 'slug' => 'campervans', 'with_front' => false ),
            'supports'           => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'page-attributes' ),
            'show_in_nav_menus'  => true,
            'publicly_queryable' => true,
            'menu_position'      => 21,
        )
    );
}
add_action( 'init', 'leni_register_campervan_post_type' );

/**
 * Add five editable starter vehicles on first theme activation.
 */
function leni_seed_starter_fleet() {
    leni_register_campervan_post_type();

    $existing = get_posts(
        array(
            'post_type'      => 'campervan',
            'post_status'    => 'any',
            'posts_per_page' => 1,
            'fields'         => 'ids',
        )
    );

    if ( $existing ) {
        flush_rewrite_rules();
        return;
    }

    $vehicles = array(
        array( 'The Causeway', 'A compact two-berth campervan made for easy coastal escapes.', 'Sleeps 2 · Kitchen · Heating · Easy to drive' ),
        array( 'The Mourne', 'A comfortable tourer with extra space for longer adventures.', 'Sleeps 2–4 · Dining area · Storage · Heating' ),
        array( 'The Fermanagh', 'A relaxed home from home for lakeland touring and quiet getaways.', 'Sleeps 4 · Kitchen · Dining · Electric hook-up' ),
        array( 'The Strangford', 'A practical family campervan with flexible living and sleeping space.', 'Family friendly · Sleeps 4 · Kitchen · Storage' ),
        array( 'The Sperrin', 'Our spacious option for travellers who want maximum comfort on the road.', 'Sleeps 4 · Premium layout · Heating · Power' ),
    );

    foreach ( $vehicles as $index => $vehicle ) {
        $content = '<!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">' . esc_html( $vehicle[1] ) . '</p><!-- /wp:paragraph -->'
            . '<!-- wp:heading {"level":2} --><h2 class="wp-block-heading">Campervan highlights</h2><!-- /wp:heading -->'
            . '<!-- wp:list {"className":"leni-check-list"} --><ul class="leni-check-list"><li>' . esc_html( $vehicle[2] ) . '</li><li>Fully equipped for your Northern Ireland road trip</li><li>Practical handover before departure</li><li>Live availability and secure booking through Booqable</li></ul><!-- /wp:list -->'
            . '<!-- wp:heading {"level":2} --><h2 class="wp-block-heading">What’s included</h2><!-- /wp:heading -->'
            . '<!-- wp:columns --><div class="wp-block-columns"><!-- wp:column --><div class="wp-block-column"><p>✓ Cooking essentials</p><p>✓ USB charging</p><p>✓ Electric hook-up cable</p></div><!-- /wp:column --><!-- wp:column --><div class="wp-block-column"><p>✓ Vehicle handover</p><p>✓ Local travel support</p><p>✓ Safety equipment</p></div><!-- /wp:column --></div><!-- /wp:columns -->'
            . '<!-- wp:heading {"level":2} --><h2 class="wp-block-heading">Ready to book?</h2><!-- /wp:heading -->'
            . '<!-- wp:paragraph --><p>Check live dates, pricing and optional extras through our secure Booqable booking page.</p><!-- /wp:paragraph -->';

        wp_insert_post(
            array(
                'post_type'    => 'campervan',
                'post_status'  => 'publish',
                'post_title'   => $vehicle[0],
                'post_excerpt' => $vehicle[1] . ' ' . $vehicle[2],
                'post_content' => $content,
                'menu_order'   => $index,
            )
        );
    }

    flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'leni_seed_starter_fleet' );

/**
 * Keep the archive ordered as a fleet rather than by publish date.
 */
function leni_order_campervan_archive( $query ) {
    if ( ! is_admin() && $query->is_main_query() && is_post_type_archive( 'campervan' ) ) {
        $query->set( 'orderby', array( 'menu_order' => 'ASC', 'title' => 'ASC' ) );
        $query->set( 'posts_per_page', 12 );
    }
}
add_action( 'pre_get_posts', 'leni_order_campervan_archive' );

/**
 * Register Northern Ireland road-trip guides and campsite directory entries.
 */
function leni_register_explore_content_types() {
    register_post_type(
        'road_trip',
        array(
            'labels' => array(
                'name'          => __( 'Road Trips', 'lets-explore-ni' ),
                'singular_name' => __( 'Road Trip', 'lets-explore-ni' ),
                'add_new_item'  => __( 'Add New Road Trip', 'lets-explore-ni' ),
                'edit_item'     => __( 'Edit Road Trip', 'lets-explore-ni' ),
                'menu_name'     => __( 'Road Trips', 'lets-explore-ni' ),
            ),
            'public'       => true,
            'show_in_rest' => true,
            'menu_icon'    => 'dashicons-location-alt',
            'menu_position'=> 22,
            'has_archive'  => 'road-trips',
            'rewrite'      => array( 'slug' => 'road-trips', 'with_front' => false ),
            'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'page-attributes' ),
        )
    );

    register_post_type(
        'campsite',
        array(
            'labels' => array(
                'name'          => __( 'Campsites', 'lets-explore-ni' ),
                'singular_name' => __( 'Campsite', 'lets-explore-ni' ),
                'add_new_item'  => __( 'Add New Campsite', 'lets-explore-ni' ),
                'edit_item'     => __( 'Edit Campsite', 'lets-explore-ni' ),
                'menu_name'     => __( 'Campsites', 'lets-explore-ni' ),
            ),
            'public'       => true,
            'show_in_rest' => true,
            'menu_icon'    => 'dashicons-palmtree',
            'menu_position'=> 23,
            'has_archive'  => 'campsites',
            'rewrite'      => array( 'slug' => 'campsites', 'with_front' => false ),
            'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'page-attributes' ),
        )
    );

    register_taxonomy(
        'explore_region',
        array( 'road_trip', 'campsite' ),
        array(
            'labels' => array(
                'name'          => __( 'Regions', 'lets-explore-ni' ),
                'singular_name' => __( 'Region', 'lets-explore-ni' ),
            ),
            'public'            => true,
            'show_in_rest'      => true,
            'show_admin_column' => true,
            'rewrite'           => array( 'slug' => 'explore-region' ),
        )
    );
}
add_action( 'init', 'leni_register_explore_content_types' );

/**
 * Seed editable Phase 4 starter content once per installation.
 */
function leni_phase4_seed_content() {
    if ( get_option( 'leni_phase4_seeded' ) ) {
        return;
    }

    leni_register_explore_content_types();

    $regions = array( 'Causeway Coast', 'Mourne Mountains', 'Fermanagh Lakelands' );
    foreach ( $regions as $region ) {
        if ( ! term_exists( $region, 'explore_region' ) ) {
            wp_insert_term( $region, 'explore_region' );
        }
    }

    $trips = array(
        array(
            'title'   => 'Causeway Coastal Route',
            'excerpt' => 'A flexible coastal itinerary linking dramatic scenery, harbour villages and famous north-coast landmarks.',
            'region'  => 'Causeway Coast',
            'days'    => 'Suggested length: 3–5 days',
            'stops'   => array( 'Belfast or pickup point', 'The Gobbins and Islandmagee', 'Glenarm and the Glens of Antrim', 'Ballycastle', 'Giant’s Causeway area', 'Portrush and Portstewart' ),
        ),
        array(
            'title'   => 'Mourne Mountains Escape',
            'excerpt' => 'A relaxed mountain-and-coast route with forest walks, seaside stops and plenty of room to slow down.',
            'region'  => 'Mourne Mountains',
            'days'    => 'Suggested length: 2–4 days',
            'stops'   => array( 'Newcastle', 'Tollymore Forest Park', 'Silent Valley area', 'Annalong', 'Kilkeel and the coast', 'Castlewellan Forest Park' ),
        ),
        array(
            'title'   => 'Fermanagh Lakelands',
            'excerpt' => 'Quiet roads, waterside viewpoints and easy-going touring through Northern Ireland’s lakeland landscape.',
            'region'  => 'Fermanagh Lakelands',
            'days'    => 'Suggested length: 3–4 days',
            'stops'   => array( 'Enniskillen', 'Lower Lough Erne', 'Marble Arch area', 'Florence Court', 'Belleek', 'Upper Lough Erne' ),
        ),
    );

    foreach ( $trips as $index => $trip ) {
        $existing = get_page_by_title( $trip['title'], OBJECT, 'road_trip' );
        if ( $existing ) {
            continue;
        }
        $list = '';
        foreach ( $trip['stops'] as $stop ) {
            $list .= '<li>' . esc_html( $stop ) . '</li>';
        }
        $map_url = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $trip['title'] . ', Northern Ireland' );
        $content = '<!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">' . esc_html( $trip['excerpt'] ) . '</p><!-- /wp:paragraph -->'
            . '<!-- wp:group {"className":"leni-trip-facts","layout":{"type":"flex","flexWrap":"wrap"}} --><div class="wp-block-group leni-trip-facts"><p><strong>' . esc_html( $trip['days'] ) . '</strong></p><p><strong>Travel style:</strong> flexible campervan touring</p></div><!-- /wp:group -->'
            . '<!-- wp:heading {"level":2} --><h2 class="wp-block-heading">Suggested route</h2><!-- /wp:heading -->'
            . '<!-- wp:list {"ordered":true,"className":"leni-itinerary-list"} --><ol class="leni-itinerary-list">' . $list . '</ol><!-- /wp:list -->'
            . '<!-- wp:heading {"level":2} --><h2 class="wp-block-heading">Plan your stops</h2><!-- /wp:heading -->'
            . '<!-- wp:paragraph --><p>Check opening times, overnight rules, road conditions and campsite availability before travelling. Keep the itinerary flexible and allow extra time for viewpoints and short walks.</p><!-- /wp:paragraph -->'
            . '<!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $map_url ) . '" target="_blank" rel="noreferrer noopener">Open area in Google Maps</a></div><!-- /wp:button --></div><!-- /wp:buttons -->';
        $post_id = wp_insert_post(
            array(
                'post_type'    => 'road_trip',
                'post_status'  => 'publish',
                'post_title'   => $trip['title'],
                'post_excerpt' => $trip['excerpt'],
                'post_content' => $content,
                'menu_order'   => $index,
            )
        );
        if ( $post_id && ! is_wp_error( $post_id ) ) {
            wp_set_object_terms( $post_id, $trip['region'], 'explore_region' );
        }
    }

    $campsites = array(
        array( 'North Coast campsite placeholder', 'Causeway Coast', 'Replace this starter entry with a campsite you personally recommend near the north coast.' ),
        array( 'Mournes campsite placeholder', 'Mourne Mountains', 'Replace this starter entry with a verified campervan-friendly campsite near the Mournes.' ),
        array( 'Fermanagh campsite placeholder', 'Fermanagh Lakelands', 'Replace this starter entry with a verified campsite or touring park in Fermanagh.' ),
    );
    foreach ( $campsites as $index => $site ) {
        if ( get_page_by_title( $site[0], OBJECT, 'campsite' ) ) {
            continue;
        }
        $content = '<!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">' . esc_html( $site[2] ) . '</p><!-- /wp:paragraph -->'
            . '<!-- wp:heading {"level":2} --><h2 class="wp-block-heading">Campsite details to add</h2><!-- /wp:heading -->'
            . '<!-- wp:list {"className":"leni-check-list"} --><ul class="leni-check-list"><li>Official website and booking link</li><li>Seasonal opening dates</li><li>Electric hook-up availability</li><li>Facilities and accessibility</li><li>Maximum vehicle size and arrival rules</li></ul><!-- /wp:list -->'
            . '<!-- wp:paragraph --><p><em>This is starter content, not a verified recommendation. Please replace it with accurate information before publishing the directory publicly.</em></p><!-- /wp:paragraph -->';
        $post_id = wp_insert_post(
            array(
                'post_type'    => 'campsite',
                'post_status'  => 'draft',
                'post_title'   => $site[0],
                'post_excerpt' => $site[2],
                'post_content' => $content,
                'menu_order'   => $index,
            )
        );
        if ( $post_id && ! is_wp_error( $post_id ) ) {
            wp_set_object_terms( $post_id, $site[1], 'explore_region' );
        }
    }

    update_option( 'leni_phase4_seeded', '1' );
    update_option( 'leni_phase4_flush_rewrites', '1' );
}
add_action( 'admin_init', 'leni_phase4_seed_content' );

/** Flush route rules once after Phase 4 is installed. */
function leni_phase4_flush_rewrites() {
    if ( get_option( 'leni_phase4_flush_rewrites' ) ) {
        leni_register_explore_content_types();
        flush_rewrite_rules();
        delete_option( 'leni_phase4_flush_rewrites' );
    }
}
add_action( 'admin_init', 'leni_phase4_flush_rewrites', 20 );

/** Order directory archives by the editor-controlled page order. */
function leni_order_explore_archives( $query ) {
    if ( ! is_admin() && $query->is_main_query() && ( is_post_type_archive( 'road_trip' ) || is_post_type_archive( 'campsite' ) ) ) {
        $query->set( 'orderby', array( 'menu_order' => 'ASC', 'title' => 'ASC' ) );
        $query->set( 'posts_per_page', 12 );
    }
}
add_action( 'pre_get_posts', 'leni_order_explore_archives' );

/** Create useful editorial categories for the SEO blog plan. */
function leni_phase4_seed_blog_categories() {
    if ( get_option( 'leni_phase4_blog_categories' ) ) {
        return;
    }
    $categories = array(
        'Campervan Guides',
        'Northern Ireland Road Trips',
        'Campsites & Overnight Stops',
        'Travel Tips',
    );
    foreach ( $categories as $category ) {
        if ( ! term_exists( $category, 'category' ) ) {
            wp_insert_term( $category, 'category' );
        }
    }
    update_option( 'leni_phase4_blog_categories', '1' );
}
add_action( 'admin_init', 'leni_phase4_seed_blog_categories' );

/** Add lightweight structured data for the new guide content. */
function leni_explore_structured_data() {
    if ( ! is_singular( array( 'road_trip', 'campsite' ) ) ) {
        return;
    }

    $post_id = get_queried_object_id();
    $type    = get_post_type( $post_id );
    $schema  = array(
        '@context'      => 'https://schema.org',
        '@type'         => 'road_trip' === $type ? 'TouristTrip' : 'Campground',
        'name'          => get_the_title( $post_id ),
        'description'   => wp_strip_all_tags( get_the_excerpt( $post_id ) ),
        'url'           => get_permalink( $post_id ),
        'mainEntityOfPage' => get_permalink( $post_id ),
    );

    $image = get_the_post_thumbnail_url( $post_id, 'full' );
    if ( $image ) {
        $schema['image'] = $image;
    }

    if ( 'road_trip' === $type ) {
        $schema['touristType'] = array( 'Campervan travellers', 'Road trippers' );
    }

    echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}
add_action( 'wp_head', 'leni_explore_structured_data', 20 );


/** Register editable customer stories. Publish only genuine, consented reviews. */
function leni_register_testimonial_post_type() {
    register_post_type( 'testimonial', array(
        'labels' => array(
            'name' => __( 'Customer Stories', 'lets-explore-ni' ),
            'singular_name' => __( 'Customer Story', 'lets-explore-ni' ),
            'add_new_item' => __( 'Add Customer Story', 'lets-explore-ni' ),
            'edit_item' => __( 'Edit Customer Story', 'lets-explore-ni' ),
            'menu_name' => __( 'Customer Stories', 'lets-explore-ni' ),
        ),
        'public' => false,
        'show_ui' => true,
        'show_in_rest' => true,
        'menu_icon' => 'dashicons-format-quote',
        'menu_position' => 24,
        'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ),
    ) );
}
add_action( 'init', 'leni_register_testimonial_post_type' );

/** Render published customer stories without inventing review content. */
function leni_testimonials_shortcode() {
    $stories = get_posts( array(
        'post_type' => 'testimonial', 'post_status' => 'publish',
        'posts_per_page' => 3, 'orderby' => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
    ) );
    if ( ! $stories ) {
        return '<div class="leni-review-empty"><p><strong>Customer stories coming soon.</strong></p><p>Add genuine, consented reviews under <em>Customer Stories</em> in WordPress. Drafts never appear publicly.</p></div>';
    }
    $html = '<div class="leni-review-grid">';
    foreach ( $stories as $story ) {
        $quote = has_excerpt( $story ) ? get_the_excerpt( $story ) : wp_trim_words( wp_strip_all_tags( $story->post_content ), 42 );
        $html .= '<article class="leni-review-card"><div class="leni-stars" aria-label="Five-star customer review">★★★★★</div><blockquote>“' . esc_html( $quote ) . '”</blockquote><p><strong>' . esc_html( get_the_title( $story ) ) . '</strong></p></article>';
    }
    return $html . '</div>';
}
add_shortcode( 'leni_testimonials', 'leni_testimonials_shortcode' );

/** Secure front-end enquiry form. */
function leni_enquiry_form_shortcode() {
    $status = isset( $_GET['enquiry'] ) ? sanitize_key( wp_unslash( $_GET['enquiry'] ) ) : '';
    $notice = '';
    if ( 'sent' === $status ) $notice = '<div class="leni-form-notice is-success" role="status">Thanks — your enquiry has been sent. We’ll reply as soon as possible.</div>';
    if ( 'error' === $status ) $notice = '<div class="leni-form-notice is-error" role="alert">Sorry, the message could not be sent. Please try again or use the Booqable booking page.</div>';
    ob_start(); echo $notice; ?>
    <form class="leni-enquiry-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
        <input type="hidden" name="action" value="leni_send_enquiry">
        <?php wp_nonce_field( 'leni_enquiry', 'leni_enquiry_nonce' ); ?>
        <div class="leni-form-grid">
            <p><label for="leni-name">Name <span aria-hidden="true">*</span></label><input id="leni-name" name="name" type="text" autocomplete="name" required></p>
            <p><label for="leni-email">Email <span aria-hidden="true">*</span></label><input id="leni-email" name="email" type="email" autocomplete="email" required></p>
            <p><label for="leni-phone">Phone</label><input id="leni-phone" name="phone" type="tel" autocomplete="tel"></p>
            <p><label for="leni-dates">Preferred dates</label><input id="leni-dates" name="dates" type="text" placeholder="For example, 14–18 August"></p>
        </div>
        <p><label for="leni-message">How can we help? <span aria-hidden="true">*</span></label><textarea id="leni-message" name="message" rows="7" required></textarea></p>
        <p class="leni-honeypot" aria-hidden="true"><label>Leave empty<input type="text" name="website" tabindex="-1" autocomplete="off"></label></p>
        <button type="submit">Send enquiry</button>
        <p class="leni-form-privacy">Your details are used only to respond to this enquiry. See our <a href="/privacy-policy/">privacy policy</a>.</p>
    </form><?php
    return ob_get_clean();
}
add_shortcode( 'leni_enquiry_form', 'leni_enquiry_form_shortcode' );

function leni_handle_enquiry() {
    if ( empty( $_POST['leni_enquiry_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['leni_enquiry_nonce'] ) ), 'leni_enquiry' ) ) wp_die( esc_html__( 'Security check failed.', 'lets-explore-ni' ) );
    $redirect = wp_get_referer() ? wp_get_referer() : home_url( '/contact/' );
    if ( ! empty( $_POST['website'] ) ) wp_safe_redirect( add_query_arg( 'enquiry', 'sent', $redirect ) );
    $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
    $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
    $phone = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
    $dates = isset($_POST['dates']) ? sanitize_text_field(wp_unslash($_POST['dates'])) : '';
    $message = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
    if ( ! $name || ! is_email($email) || ! $message ) wp_safe_redirect( add_query_arg( 'enquiry', 'error', $redirect ) );
    $body = "Name: $name\nEmail: $email\nPhone: $phone\nPreferred dates: $dates\n\n$message";
    $sent = wp_mail( get_option('admin_email'), 'New campervan enquiry from ' . $name, $body, array( 'Reply-To: ' . $name . ' <' . $email . '>' ) );
    wp_safe_redirect( add_query_arg( 'enquiry', $sent ? 'sent' : 'error', $redirect ) ); exit;
}
add_action( 'admin_post_nopriv_leni_send_enquiry', 'leni_handle_enquiry' );
add_action( 'admin_post_leni_send_enquiry', 'leni_handle_enquiry' );

/** Add a keyboard-accessible skip link in block themes. */
function leni_skip_link() { echo '<a class="leni-skip-link" href="#leni-main">' . esc_html__( 'Skip to content', 'lets-explore-ni' ) . '</a>'; }
add_action( 'wp_body_open', 'leni_skip_link' );

/** Website and rental-business structured data using only known business details. */
function leni_site_structured_data() {
    if ( is_admin() ) return;
    $schema = array(
        '@context' => 'https://schema.org', '@graph' => array(
            array( '@type' => 'WebSite', '@id' => home_url('/#website'), 'url' => home_url('/'), 'name' => "Let's Explore NI", 'inLanguage' => 'en-GB' ),
            array( '@type' => array('LocalBusiness','AutoRental'), '@id' => home_url('/#business'), 'name' => "Let's Explore NI", 'url' => home_url('/'), 'areaServed' => array('@type'=>'AdministrativeArea','name'=>'Northern Ireland'), 'sameAs' => array('https://letsexploreni.booqable.com/') ),
        )
    );
    echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>\n';
}
add_action( 'wp_head', 'leni_site_structured_data', 19 );

/** Seed a native contact page and safe draft review placeholders. */
function leni_phase5_seed_content() {
    if ( get_option('leni_phase5_seeded') ) return;
    leni_register_testimonial_post_type();
    if ( ! get_page_by_path('contact') ) {
        wp_insert_post(array('post_type'=>'page','post_status'=>'publish','post_title'=>'Contact','post_name'=>'contact','post_content'=>'<!-- wp:heading {"level":1} --><h1 class="wp-block-heading">Plan your campervan adventure</h1><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">Ask about vehicles, trip planning or anything you need before booking. For live prices and dates, use our Booqable availability page.</p><!-- /wp:paragraph --><!-- wp:shortcode -->[leni_enquiry_form]<!-- /wp:shortcode -->'));
    }
    for ($i=1;$i<=3;$i++) {
        if (!get_page_by_title('Review placeholder '.$i, OBJECT, 'testimonial')) wp_insert_post(array('post_type'=>'testimonial','post_status'=>'draft','post_title'=>'Review placeholder '.$i,'post_excerpt'=>'Replace this draft with a genuine customer quote and the customer name or approved attribution.'));
    }
    update_option('leni_phase5_seeded','1');
}
add_action( 'admin_init', 'leni_phase5_seed_content' );


/**
 * Business settings used across booking calls-to-action and contact details.
 */
function leni_business_defaults() {
    return array(
        'booqable_url'       => 'https://letsexploreni.booqable.com/',
        'phone'              => '',
        'whatsapp'           => '',
        'business_email'     => get_option( 'admin_email' ),
        'google_reviews_url' => '',
        'instagram_url'      => '',
    );
}

function leni_get_business_settings() {
    return wp_parse_args( (array) get_option( 'leni_business_settings', array() ), leni_business_defaults() );
}

function leni_sanitize_business_settings( $input ) {
    $defaults = leni_business_defaults();
    $output   = array();

    $output['booqable_url']       = ! empty( $input['booqable_url'] ) ? esc_url_raw( $input['booqable_url'] ) : $defaults['booqable_url'];
    $output['phone']              = isset( $input['phone'] ) ? sanitize_text_field( $input['phone'] ) : '';
    $output['whatsapp']           = isset( $input['whatsapp'] ) ? preg_replace( '/[^0-9+]/', '', $input['whatsapp'] ) : '';
    $output['business_email']     = ! empty( $input['business_email'] ) && is_email( $input['business_email'] ) ? sanitize_email( $input['business_email'] ) : $defaults['business_email'];
    $output['google_reviews_url'] = isset( $input['google_reviews_url'] ) ? esc_url_raw( $input['google_reviews_url'] ) : '';
    $output['instagram_url']      = isset( $input['instagram_url'] ) ? esc_url_raw( $input['instagram_url'] ) : '';

    return $output;
}

function leni_register_business_settings() {
    register_setting(
        'leni_business_settings_group',
        'leni_business_settings',
        array(
            'type'              => 'array',
            'sanitize_callback' => 'leni_sanitize_business_settings',
            'default'           => leni_business_defaults(),
        )
    );

    add_settings_section(
        'leni_business_details',
        __( 'Booking and contact details', 'lets-explore-ni' ),
        function() {
            echo '<p>' . esc_html__( 'These values are used throughout the theme. Changing the Booqable URL updates every theme booking button automatically.', 'lets-explore-ni' ) . '</p>';
        },
        'leni-business-settings'
    );

    $fields = array(
        'booqable_url'       => array( 'Booqable booking URL', 'url' ),
        'phone'              => array( 'Business phone', 'text' ),
        'whatsapp'           => array( 'WhatsApp number', 'text' ),
        'business_email'     => array( 'Business email', 'email' ),
        'google_reviews_url' => array( 'Google reviews URL', 'url' ),
        'instagram_url'      => array( 'Instagram URL', 'url' ),
    );

    foreach ( $fields as $key => $field ) {
        add_settings_field(
            'leni_' . $key,
            esc_html__( $field[0], 'lets-explore-ni' ),
            function() use ( $key, $field ) {
                $settings = leni_get_business_settings();
                printf(
                    '<input class="regular-text" type="%1$s" id="leni_%2$s" name="leni_business_settings[%2$s]" value="%3$s">',
                    esc_attr( $field[1] ),
                    esc_attr( $key ),
                    esc_attr( $settings[ $key ] )
                );
            },
            'leni-business-settings',
            'leni_business_details'
        );
    }
}
add_action( 'admin_init', 'leni_register_business_settings' );

function leni_add_business_settings_page() {
    add_theme_page(
        __( 'Let’s Explore NI Settings', 'lets-explore-ni' ),
        __( 'Business Settings', 'lets-explore-ni' ),
        'manage_options',
        'leni-business-settings',
        'leni_render_business_settings_page'
    );
}
add_action( 'admin_menu', 'leni_add_business_settings_page' );

function leni_render_business_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'Let’s Explore NI Business Settings', 'lets-explore-ni' ); ?></h1>
        <form action="options.php" method="post">
            <?php
            settings_fields( 'leni_business_settings_group' );
            do_settings_sections( 'leni-business-settings' );
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

/**
 * Replace the original demo booking URL in rendered block templates.
 */
function leni_replace_booking_urls( $block_content ) {
    if ( false === strpos( $block_content, 'letsexploreni.booqable.com' ) ) {
        return $block_content;
    }

    $settings = leni_get_business_settings();
    return str_replace(
        array( 'https://letsexploreni.booqable.com/', 'https://letsexploreni.booqable.com' ),
        esc_url( $settings['booqable_url'] ),
        $block_content
    );
}
add_filter( 'render_block', 'leni_replace_booking_urls', 10, 1 );

/**
 * Shortcode for reusable business contact links.
 * Usage: [leni_business_contact type="phone|email|whatsapp"]
 */
function leni_business_contact_shortcode( $atts ) {
    $atts = shortcode_atts( array( 'type' => 'email' ), $atts, 'leni_business_contact' );
    $data = leni_get_business_settings();

    if ( 'phone' === $atts['type'] && $data['phone'] ) {
        return sprintf( '<a href="tel:%1$s">%2$s</a>', esc_attr( preg_replace( '/[^0-9+]/', '', $data['phone'] ) ), esc_html( $data['phone'] ) );
    }
    if ( 'whatsapp' === $atts['type'] && $data['whatsapp'] ) {
        $number = preg_replace( '/[^0-9]/', '', $data['whatsapp'] );
        return sprintf( '<a href="https://wa.me/%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>', esc_attr( $number ), esc_html__( 'Message us on WhatsApp', 'lets-explore-ni' ) );
    }
    if ( $data['business_email'] ) {
        return sprintf( '<a href="mailto:%1$s">%1$s</a>', antispambot( esc_attr( $data['business_email'] ) ) );
    }

    return '';
}
add_shortcode( 'leni_business_contact', 'leni_business_contact_shortcode' );
