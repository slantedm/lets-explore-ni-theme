# Contributing

## Branches

Create feature branches from `main` using a descriptive name:

```text
feature/fleet-gallery
fix/mobile-navigation
content/causeway-guide
```

## Commits

Keep commits focused and use imperative messages, for example:

```text
Add campervan gallery controls
Fix mobile booking bar overlap
```

## Pull requests

Each pull request should explain:

- what changed
- why it changed
- how it was tested
- any WordPress setup steps required after deployment

## Required checks

Before opening a pull request:

1. Run PHP syntax checks.
2. Validate `theme.json`.
3. Confirm the theme ZIP contains one top-level theme folder.
4. Test the homepage, fleet archive and one vehicle page on mobile and desktop.
5. Confirm booking links open the configured Booqable storefront.

Never publish invented customer reviews, unverified campsite details or unsupported claims about availability and pricing.
