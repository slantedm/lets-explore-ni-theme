=== LetsExploreNI ===
Requires at least: 6.2
Tested up to: 6.6
Requires PHP: 7.4

== Description ==
LetsExploreNI is a WordPress theme designed for campervan and RV rental, motorhome rental, adventure tourism, and all types of campervan rental and accommodation businesses. Fully compatible with the WordPress Block Editor, this theme offers a professional design with a 100% responsive layout and is easy to customize, so no coding is required.

== Changelog ==
= Version 1.0.1 =
* Theme updated for compatibility with Gutenverse version 3.0.0

= Version 1.0.0 =
* First release

== 1.7.0 ==
* Added GitHub-ready repository documentation and automated release packaging.
* Added development contribution and deployment guidance.
* Added automated PHP syntax and theme JSON validation workflow.

== 1.6.0 ==
* Added Appearance → Business Settings.
* Made all theme Booqable buttons configurable from one setting.
* Added reusable phone, email and WhatsApp shortcodes.
