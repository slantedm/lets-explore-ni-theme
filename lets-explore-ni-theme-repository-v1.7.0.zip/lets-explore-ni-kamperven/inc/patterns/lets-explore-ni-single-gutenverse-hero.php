<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'LetsExploreNI Single Gutenverse Hero', 'lets-explore-ni' ),
	'categories' => array( 'lets-explore-ni-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"gap":"no","elementId":"guten-135hz7","background":{"videoPlayOnMobile":false,"type":"default","image":{"Desktop":{"id":806,"image":"' . esc_url( trailingslashit( get_template_directory_uri() ) ) . 'assets/img/family-vacation-travel-rv-holiday-trip-in-motorhome-5-e1648691700496.webp"}},"position":{"Desktop":"center center","Tablet":"custom"},"xposition":{"Desktop":{"unit":"%","point":""},"Tablet":{"unit":"%","point":"0"}},"yposition":{"Desktop":{"unit":"%","point":""},"Tablet":{"unit":"%","point":"0"}},"repeat":{"Desktop":"no-repeat"},"size":{"Desktop":"cover","Tablet":"cover"}},"backgroundOverlay":{"type":"default","color":{"r":16,"g":16,"b":16,"a":1}},"opacity":"0.4","margin":{"Desktop":[],"Tablet":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"170","bottom":"100"}},"Tablet":{"unit":"px","dimension":{"right":"20","left":"20"}},"Mobile":{"unit":"px","dimension":{"top":"150","bottom":"80"}}}} -->
<div class="section-wrapper" data-id="135hz7"><section class="wp-block-gutenverse-section guten-element guten-section guten-135hz7 layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-QbcCIL","horizontalAlign":{"Desktop":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-QbcCIL"><div class="guten-column-wrapper" data-id="QbcCIL"><!-- wp:gutenverse/post-title {"elementId":"guten-2oCrRV","alignment":{"Desktop":"center"},"typography":{"type":"variable","id":"QOfz7B","font":{"label":"Ubuntu","value":"Ubuntu","type":"google"},"size":{"Desktop":{"point":"40","unit":"px"},"Tablet":{"point":"38","unit":"px"},"Mobile":{"point":"36","unit":"px"}},"weight":"600","lineHeight":{"Desktop":{"unit":"em","point":"1"},"Mobile":{"unit":"em","point":""}}},"color":{"type":"variable","id":"theme-3"},"margin":{"Desktop":[]},"padding":{"Desktop":{"unit":"px","dimension":{"bottom":"30"}}}} -->
<div class="guten-element guten-post-title guten-2oCrRV"></div>
<!-- /wp:gutenverse/post-title -->

<!-- wp:gutenverse/icon {"elementId":"guten-gLogb7","icon":"fas fa-user-circle","iconColorOne":{"r":77,"g":122,"b":77,"a":0},"iconSize":{"Desktop":{"point":"15","unit":"px"}},"iconPadding":{"Desktop":"0"},"iconColorTwo":{"type":"variable","id":"theme-5"},"margin":{"Desktop":{"unit":"px","dimension":{"top":"-2"}},"Tablet":[]},"padding":{"Desktop":{"unit":"px","dimension":{"right":"10","left":""}},"Tablet":[]},"positioningType":{"Desktop":"inline"}} -->
<div class="wp-block-gutenverse-icon guten-element guten-gLogb7 guten-icon"><span class="guten-icon-wrapper rounded stacked"><i class="fas fa-user-circle"></i></span></div>
<!-- /wp:gutenverse/icon -->

<!-- wp:gutenverse/post-author {"elementId":"guten-OU3FFI","alignment":{"Desktop":"flex-start"},"typography":{"type":"variable","id":"ep7KGb","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"},"Tablet":{"point":"16","unit":"px"},"Mobile":{"point":"14","unit":"px"}},"weight":"400","lineHeight":{"Desktop":{"unit":"em","point":"1.5"},"Tablet":{"unit":"em","point":""},"Mobile":{"unit":"em","point":""}}},"color":{"type":"variable","id":"theme-3"},"authorBorder":{"radius":{"Desktop":[]}},"authorBorderResponsive":{"Desktop":{"radius":[]}},"border":{"radius":{"Desktop":[]}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-post-author guten-OU3FFI"></div>
<!-- /wp:gutenverse/post-author -->

<!-- wp:gutenverse/icon {"elementId":"guten-q9f4ZC","icon":"fas fa-calendar-alt","iconColorOne":{"r":77,"g":122,"b":77,"a":0},"iconSize":{"Desktop":{"point":"15","unit":"px"}},"iconPadding":{"Desktop":"0"},"iconColorTwo":{"type":"variable","id":"theme-5"},"margin":{"Desktop":{"unit":"px","dimension":{"top":"-2","right":"0","bottom":"0","left":"0"}}},"padding":{"Desktop":{"unit":"px","dimension":{"right":"10","left":"20","top":"0","bottom":"0"}}},"positioningType":{"Desktop":"inline"}} -->
<div class="wp-block-gutenverse-icon guten-element guten-q9f4ZC guten-icon"><span class="guten-icon-wrapper rounded stacked"><i class="fas fa-calendar-alt"></i></span></div>
<!-- /wp:gutenverse/icon -->

<!-- wp:gutenverse/post-date {"elementId":"guten-IPVn2S","alignment":{"Desktop":"flex-start"},"typography":{"type":"variable","id":"ep7KGb","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"},"Tablet":{"point":"16","unit":"px"},"Mobile":{"point":"14","unit":"px"}},"weight":"400","lineHeight":{"Desktop":{"unit":"em","point":"1.5"},"Tablet":{"unit":"em","point":""},"Mobile":{"unit":"em","point":""}}},"color":{"type":"variable","id":"theme-3"},"border":{"radius":{"Desktop":[]}},"positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-post-date guten-IPVn2S"></div>
<!-- /wp:gutenverse/post-date -->

<!-- wp:gutenverse/icon {"elementId":"guten-qOakrz","icon":"far fa-folder-open","iconColorOne":{"r":77,"g":122,"b":77,"a":0},"iconSize":{"Desktop":{"point":"15","unit":"px"}},"iconPadding":{"Desktop":"0"},"iconColorTwo":{"type":"variable","id":"theme-5"},"margin":{"Desktop":[]},"padding":{"Desktop":{"unit":"px","dimension":{"right":"10","left":"20"}}},"positioningType":{"Desktop":"inline"}} -->
<div class="wp-block-gutenverse-icon guten-element guten-qOakrz guten-icon"><span class="guten-icon-wrapper rounded stacked"><i class="far fa-folder-open"></i></span></div>
<!-- /wp:gutenverse/icon -->

<!-- wp:gutenverse/post-terms {"elementId":"guten-FEsxW8","linkTo":"term","alignment":{"Desktop":"flex-start"},"typography":{"type":"variable","id":"ep7KGb","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"},"Tablet":{"point":"16","unit":"px"},"Mobile":{"point":"14","unit":"px"}},"weight":"400","lineHeight":{"Desktop":{"unit":"em","point":"1.5"},"Tablet":{"unit":"em","point":""},"Mobile":{"unit":"em","point":""}}},"color":{"type":"variable","id":"theme-3"},"positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-post-terms guten-FEsxW8"></div>
<!-- /wp:gutenverse/post-terms --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
	'images'      => '',
	'is_sync' => false,
);
