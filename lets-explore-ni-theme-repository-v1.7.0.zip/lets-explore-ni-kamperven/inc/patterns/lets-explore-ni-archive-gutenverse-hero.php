<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'LetsExploreNI Archive Gutenverse Hero', 'lets-explore-ni' ),
	'categories' => array( 'lets-explore-ni-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"gap":"no","elementId":"guten-135hz7","background":{"videoPlayOnMobile":false,"type":"default","image":{"Desktop":{"id":806,"image":"' . esc_url( trailingslashit( get_template_directory_uri() ) ) . 'assets/img/family-vacation-travel-rv-holiday-trip-in-motorhome-5-e1648691700496.webp"}},"position":{"Desktop":"center center","Tablet":"custom"},"xposition":{"Desktop":{"unit":"%","point":""},"Tablet":{"unit":"%","point":"0"}},"yposition":{"Desktop":{"unit":"%","point":""},"Tablet":{"unit":"%","point":"0"}},"repeat":{"Desktop":"no-repeat"},"size":{"Desktop":"cover","Tablet":"cover"}},"backgroundOverlay":{"type":"default","color":{"r":16,"g":16,"b":16,"a":1}},"opacity":"0.4","margin":{"Desktop":[],"Tablet":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"170","bottom":"100"}},"Tablet":{"unit":"px","dimension":{"right":"20","left":"20"}},"Mobile":{"unit":"px","dimension":{"top":"150","bottom":"80"}}}} -->
<div class="section-wrapper" data-id="135hz7"><section class="wp-block-gutenverse-section guten-element guten-section guten-135hz7 layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-QbcCIL","margin":{"Desktop":{"unit":"px","dimension":{"bottom":""}}},"padding":{"Desktop":[]}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-QbcCIL"><div class="guten-column-wrapper" data-id="QbcCIL"><!-- wp:gutenverse/archive-title {"elementId":"guten-HWprgB","alignment":{"Desktop":"flex-start"},"typography":{"type":"variable","id":"QOfz7B","font":{"label":"Ubuntu","value":"Ubuntu","type":"google"},"size":{"Desktop":{"point":"40","unit":"px"},"Tablet":{"point":"38","unit":"px"},"Mobile":{"point":"36","unit":"px"}},"weight":"600","lineHeight":{"Desktop":{"unit":"em","point":"1"},"Mobile":{"unit":"em","point":""}}},"color":{"type":"variable","id":"theme-3"}} -->
<div class="guten-element guten-archive-title guten-HWprgB"></div>
<!-- /wp:gutenverse/archive-title --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
	'images'      => '',
	'is_sync' => false,
);
