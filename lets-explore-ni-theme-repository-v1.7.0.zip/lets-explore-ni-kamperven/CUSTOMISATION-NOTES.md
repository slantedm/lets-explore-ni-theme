# Let’s Explore NI – Kamperven Edition

## Included in this build
- Complete public rebrand and new WordPress theme metadata.
- Let’s Explore NI colour palette and branded global styles.
- Rebranded block-pattern namespace and PHP namespace.
- Updated starter copy for campervan hire in Northern Ireland.
- Booqable-ready CTA styling for links pointing to `booqable.com`.
- New SVG logo at `assets/img/lets-explore-ni-logo.svg`.

## Recommended setup
1. Install and activate Gutenverse and the companion plugin requested by the theme.
2. Activate this theme under Appearance → Themes.
3. Add the supplied SVG logo in Appearance → Editor → Header.
4. Set booking buttons to `https://letsexploreni.booqable.com/`.
5. Import or recreate the starter pages from the included Gutenverse page definitions.

## Important
This package retains the original GPL licence notices and is a customised derivative of the Kamperven theme. Keep a backup before replacing a live theme.


## Version 1.2.0 – Homepage rebuild
- Added a native block-based `front-page.html`.
- Replaced pattern-only header and footer with editable core WordPress blocks.
- Added hero, fleet, route, booking steps, benefits, FAQ and final booking CTA sections.
- Added responsive styling and direct Booqable links.
- Uses bundled theme images, avoiding reliance on imported demo content.

## Version 1.4.0 – Fleet system
- Added a native `campervan` custom post type in WordPress.
- Added `/campervans/` archive with editable fleet cards and comparison table.
- Added individual campervan templates with booking sidebar, FAQs and sticky mobile booking CTA.
- Added five editable starter vehicles on first theme activation.
- Starter specifications are placeholders and should be replaced with exact fleet data.

## Phase 4 — Explore content

The dashboard now includes **Road Trips** and **Campsites**.

- Three published starter road-trip guides are created automatically once.
- Three campsite placeholders are created as drafts because campsite details must be verified before publication.
- Assign a Region, excerpt and featured image to every entry.
- Replace all starter itinerary wording with your own recommendations and current local information.
- Campsite entries should include the official website, booking link, opening season, facilities, vehicle restrictions and last-verified date.
- After updating the theme, visit **Settings → Permalinks** and click **Save Changes** if either archive returns a 404.


## Sprint 5 (v1.5.0)
- Contact page and secure enquiry form shortcode
- Editable Customer Stories post type; placeholders remain drafts
- Homepage customer-story section
- Skip link, keyboard focus and reduced-motion support
- WebSite and AutoRental structured data
- No fabricated reviews or unverified contact details are published
